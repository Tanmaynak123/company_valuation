export interface ICompany {
  id: number,
  name: string,
  age: number,
  college: string,
  field: string
}
